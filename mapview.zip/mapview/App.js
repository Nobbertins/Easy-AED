import React, { useState, useEffect } from 'react';
import MapView, { Marker } from 'react-native-maps';
import { StyleSheet, View, Text, Pressable, Image } from 'react-native';
import * as Location from 'expo-location';
import logo from './assets/drone.jpg';
export default function App() {
  const [mapRegion, setMapRegion] = useState({
    latitude: 37.78825,
    longitude: -122.4324,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  });
  const [droneLocation, setDroneLocation] = useState({
    latitude: 37.78825,
    longitude: -122.4324,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  });
  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  function mainPress() {
    fetch('https://ipp77fz2z8.execute-api.eu-north-1.amazonaws.com/Dev', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        ID: 'phone',
        gps:
          JSON.stringify(location.coords.longitude) +
          ',' +
          JSON.stringify(location.coords.latitude),
      }),
    })
      .then((res) => {
        return res.json();
      })
      .then((data) => console.log(data))
      .catch((error) => console.log('error'));
    alert('GPS Location successfully sent to the hospital');
  }
  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Permission to access location was denied');
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      setLocation(location);
      setMapRegion({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        latitudeDelta: mapRegion.latitudeDelta,
        longitudeDelta: mapRegion.longitudeDelta,
      });
    })();
  }, []);

  let text = 'Waiting..';
  if (errorMsg) {
    text = errorMsg;
  } else if (location) {
    text = JSON.stringify(location);
  }
  useEffect(() => {
    function setVal(d) {
      let fullData = d.body.drone.Item.GPS.split(',');
      setDroneLocation({
        latitude: JSON.parse(fullData[1]),
        longitude: JSON.parse(fullData[0]),
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
      });
    }
    const interval = setInterval(function () {
      fetch('https://ipp77fz2z8.execute-api.eu-north-1.amazonaws.com/Dev')
        .then((res) => {
          return res.json();
        })
        .then((data) => setVal(data))
        .catch((error) => console.log(error));
    }, 100);
    return () => {
      clearInterval(interval);
    };
  });
  return (
    <View style={styles.container}>
      <MapView style={styles.map} showsUserLocation={true} region={mapRegion}>
        <Marker coordinate={droneLocation} title="Marker">
          <Image style={{ width: 50, height: 50 }} source={logo} />
        </Marker>
      </MapView>
      <Pressable onPress={mainPress} style={styles.button}>
        <Text style={styles.headText} selectable={false}>
          Request Drone
        </Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    width: '100%',
    height: '90%',
  },
  headText: {
    fontStyle: 'arial',
    color: '#2700d6',
    marginHorizontal: 24,
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#c7e2ff',
    marginHorizontal: 30,
    marginVertical: 20,
    borderWidth: 2,
    borderRadius: 8,
    padding: 3,
  },
});
